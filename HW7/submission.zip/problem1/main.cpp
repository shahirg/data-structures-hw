#include <iostream>
#include "solution.hpp"
using namespace std;

int main() {
    return 0;
}