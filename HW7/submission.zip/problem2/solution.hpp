#include <string>
class Solution {
public:
    bool evaluate(std::string input);
};