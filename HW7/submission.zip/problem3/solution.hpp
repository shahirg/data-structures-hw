#include <string>
class Solution {
public:
    std::string evaluate(std::string input);
};