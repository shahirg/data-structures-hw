class Solution {
public:
    int evaluate(int input);
};