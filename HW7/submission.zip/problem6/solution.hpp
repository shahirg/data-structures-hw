#include <string>
class Solution {
public:
    std::string getPermutation(int n, int k);
};