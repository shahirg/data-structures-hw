#include <vector>

class Solution {
public:
    int countBattleships(std::vector<std::vector<char>>& board);
};
