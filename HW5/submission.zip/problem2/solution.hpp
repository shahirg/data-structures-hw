#include <string>

class Solution {
public:
    int minimumDeletions(std::string s) {

    }
};
