#include "solution.hpp"
using std::string;

int Solution::minimumDeletions(string s) {

}
