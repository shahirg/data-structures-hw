#include <string>

class Solution {
public:
    std::string removeOuterParentheses(std::string s);
};
