#include <iostream>
#include "solution.cpp"
using namespace std;

int main() {
    Solution s;
    cout << s.reorganizeString("aab") << endl;
    cout << s.reorganizeString("aaab") << endl;
    return 0;
}