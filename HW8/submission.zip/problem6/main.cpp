#include <iostream>
#include "solution.cpp"
using namespace std;

int main() {
    Solution s;
    cout << s.eval("baaca", 3) << endl;
    return 0;
}