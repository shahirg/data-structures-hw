
class Solution {
public:
    int getPrimes(int n);
    bool isPrime(int n);
};