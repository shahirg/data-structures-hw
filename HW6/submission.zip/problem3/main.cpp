#include <iostream>
#include "solution.hpp"
using namespace std;

int main() {
    Solution s;
    cout << s.getPrimes(10) << endl;
    return 0;
}