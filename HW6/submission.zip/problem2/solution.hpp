#include <vector>
class Solution {
public:
    int gcd(std::vector<int> list);
    int gcd(int x, int y);
};