#include <vector>
class Solution {
public:
    bool isGood(std::vector<int> nums);
    int gcd(int x, int y);
};