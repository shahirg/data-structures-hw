#include <vector>

class Solution {
public:
    int getScore(std::vector<int> nums);
    int gcd(int x, int y);
};