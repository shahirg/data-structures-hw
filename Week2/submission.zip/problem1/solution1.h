#include <vector>
#include <algorithm>
using std::vector;
class Solution {
public:
    vector<int> twoSum(vector<int>& nums, int target) {
        vector<int> output;

        // itereate through all possible combinations
        for (int i = 0; i < nums.size() - 1; i++) {
            for (int j = i + 1; j < nums.size(); j++) {
                // when combination found return
                if (nums[i] + nums[j] == target) {
                    output.push_back(nums[i]);
                    output.push_back(nums[j]);
                    return output;
                }
            }
        }
        return output;
    }

    vector<int> twoSumEfficient(vector<int>& nums, int target) {
        vector<int> output; // declare output
        sort(nums.begin(), nums.end()); // sort vector
        int leftInd = 0, rightInd = nums.size() - 1; // declare ptrs
        int sum = nums[leftInd] + nums[rightInd]; // get sum
        // adjust index values until target found
        while (sum != target && leftInd < rightInd) {
            if (sum < target) {
                leftInd += 1;
            }
            else if (sum > target) {
                rightInd -= 1;
            }
            sum = nums[leftInd] + nums[rightInd]; // get new sum
        }
        output.push_back(nums[leftInd]);
        output.push_back(nums[rightInd]);
        return output; // return output
    }
};