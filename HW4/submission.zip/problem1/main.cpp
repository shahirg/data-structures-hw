#include <iostream>
#include "solution.h"
using namespace std;

int main() {
    Solution s;
    cout << s.strStr("abcdefghijk", "ghi") << endl;
    return 0;
}