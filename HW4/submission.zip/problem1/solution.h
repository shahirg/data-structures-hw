#include <string>

class Solution {
public:
    int strStr(std::string haystack, std::string needle);
    int* calcPreficLen(std::string pattern);
};
