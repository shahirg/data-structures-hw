#include <string>

class Solution {
public:
    bool rotateString(std::string s, std::string goal);
};
