#include <string>

class Solution {
public:
    std::string shortestPalindrome(std::string s);
    bool checkPalindrome(std::string s);
};
