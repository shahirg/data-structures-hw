#include <string>

class Solution {
public:
    std::string longestPrefix(std::string s);
};
