#include <iostream>
#include "solution.h"
using namespace std;

int main() {
    Solution s;
    cout << s.repeatedStringMatch("a", "aa") << endl;
    return 0;
}