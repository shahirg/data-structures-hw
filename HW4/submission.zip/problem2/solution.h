#include <string>
class Solution {
public:
    int repeatedStringMatch(std::string a, std::string b);
};
