#include <iostream>
#include "solution.cpp"
using namespace std;

int main() {
    Solution s;
    cout << s.leastPerfectSquares(12) << endl;
    cout << s.leastPerfectSquares(13) << endl;
    return 0;
}