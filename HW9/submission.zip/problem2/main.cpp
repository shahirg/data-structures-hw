#include <iostream>
#include "solution.cpp"
using namespace std;

int main() {
    return 0;
}