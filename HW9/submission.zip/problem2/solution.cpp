#include <vector>
using namespace std;
class Solution {
public:
    int largestRectangle(vector<vector<int>> matrix) {
        bool down, right;
        vector<vector<int>> visited;
        int max = 0;
        for (int r = 0; r < matrix.size(); r++) {
            for (int c = 0; c < matrix.at(0).size(); c++) {

            }
        }
    }
};