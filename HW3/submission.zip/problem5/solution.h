#include<vector>

class Solution {
public:
    int countRangeSum(std::vector<int>& nums, int lower, int upper);
};
