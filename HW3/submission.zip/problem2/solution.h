#include <string>

class Solution {
public:
    std::string decodeString(std::string s);
};
