#include <iostream>
#include "solution.h"
using namespace std;

int main() {
    Solution s;
    // cout << s.calculate("3+2") << endl;
    // cout << s.calculate("3+2") << endl;
    // cout << s.calculate("3+2") << endl;
    cout << s.calculate("(1+(4+5+2)-3)+(6+8)") << endl;
    return 0;
}