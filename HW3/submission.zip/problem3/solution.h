#include <string>


class Solution {
public:
    int calculate(std::string s);
};