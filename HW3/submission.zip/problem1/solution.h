#include <string>
#include <vector>

class Solution {
public:
    int calPoints(std::vector<std::string>& ops);
};
