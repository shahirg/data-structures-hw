#include "NestedIterator.h"
using std::vector;

NestedIterator::NestedIterator(vector<NestedInteger>& nestedList) {

}

int NestedIterator::next() {
    if (NestedIterator::hasNext()) {

    }
}

bool NestedIterator::hasNext() {

}

