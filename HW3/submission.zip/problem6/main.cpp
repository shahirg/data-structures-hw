#include <iostream>
#include "solution.h"
using namespace std;

int main() {
    ListNode* out;
    out->val = 2;
    cout << out->val;
    Solution s;
    // ListNode* test = s.sortList(&out);
    // while (test != nullptr) {
    //     cout << test->val << endl;
    //     test = test->next;
    // }
    return 0;
}