#include "ListNode.h"
class Solution {
public:
    ListNode* sortList(ListNode* head);
    ListNode* merge(ListNode* l1, ListNode* l2);
    void split(ListNode* head, ListNode** front, ListNode** back);
};
