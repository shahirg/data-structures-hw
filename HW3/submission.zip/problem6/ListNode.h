class ListNode {
public:
    int val;
    ListNode* next;
    ~ListNode();
    ListNode();
    ListNode(int x);
    ListNode(int x, ListNode* next);



};